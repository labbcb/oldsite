Este repositório possui o material para as aulas de Métodos Computacionais em Estatística ministrado por Benilton Carvalho / UNICAMP.

Use este material, mas faça as referências apropriadas.

