---
layout: post
title: Bem-vindos
---

Bem-vindos à disciplina **Métodos Computacionais em Estatística**. Use os links acima para maiores informações.
